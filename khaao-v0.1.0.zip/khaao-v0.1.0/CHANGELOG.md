# Changelog

## v0.1.0 — Thin Slice (2026-07-20)

First runnable release. Scope: Orchestrator + Support + Monitor against a
single restaurant. Design law: prompts are requests, code is law.

### Added
- Enforcement layer (`enforcement.py`) — sole agent-callable surface:
  - `issue_refund`: Rs 500 auto cap, one-refund-per-order, refund ≤ order
    total, Rs 15,000 rolling-7-day ledger hard stop, per-customer velocity
    (3rd refund in 30 days escalates, never auto-pays)
  - `get_order`: PII returned only to the fulfilling restaurant on an
    active order; all other access denied and logged
  - `log_event`: append-only run log (no update/delete path in codebase)
- Escalation queue with URGENT categories (food_safety, legal,
  money_anomaly) triggering same-day page instead of weekly audit
- Support agent (multilingual, injection-refusing), Orchestrator (tier
  routing), Monitor (read-only sweep + owner digest)
- MockLLM offline mode: deterministic, deliberately naive-obedient, so the
  simulation proves guarantees come from code, not model behavior
- Event-driven webhook entry (`webhook.py`); cron reserved for digests and
  payout statements
- End-to-end simulation (`simulate.py`) covering 10 adversarial traces

### Fixed during build
- SQLite deadlock from nested connections in transactional logging
- Rollback-loss bug: violation evidence written immediately before a
  rejection was being rolled back with the transaction; audit records now
  commit independently before the raise

### Known limitations
- Payout execution not implemented (statements only; rail executes)
- Single-process SQLite: fine for pilot volume, not for scale
- MockLLM heuristics are test scaffolding, not production NLU
- WhatsApp provider integration is a stub (send-API call site marked)

### Gate to v0.2.0
50 clean real orders through one restaurant. Then, in order: Onboarding
agent, Finance statements, Content agent.
